import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { getCurrentUser, refreshAccessToken } from "../../api/user.api";
import { setAccessToken } from "../../utils/axiosInstance";

const initialState = {
  user: null,
  loading: true,
  error: null,
};
export let authInitPromise = null;
export const setAuthInitPromise = (promise) => {
  authInitPromise = promise;
}
const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login(state, action) {
      console.log("$$$$$$$")
      console.log(action.payload);
      state.user = action.payload.user;
    },
    logout(state) {
      state.user = null;
    },
    setVerified(state) {
      if (state.user) {
        state.user.isVerified = true;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(initializeAuth.pending, (state) => {
        state.loading = true;
      })
      .addCase(initializeAuth.fulfilled, (state, action) => {
        state.user = action.payload;
        state.loading = false;
      })
      .addCase(initializeAuth.rejected, (state) => {
        state.user = null;
        state.loading = false;
      });
  },
});
export const initializeAuth = createAsyncThunk(
  "auth/initialize",
  async (_, { rejectWithValue }) => {
    try {
      const user = await getCurrentUser();
      return user;
    } catch {
      return rejectWithValue("Not authenticated");
    }
  },
);
export const { login, logout, setLoading, setError, setVerified } = authSlice.actions;
export default authSlice.reducer;
