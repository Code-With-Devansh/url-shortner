import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
// https://vite.dev/config/
export default defineConfig({
  server: {
    headers: {
      "Cache-Control": "no-store",
    },
  },
  plugins: [react(), tailwindcss()],
});
